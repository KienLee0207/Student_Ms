<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class book extends Model
{
    protected $table='book';
    protected $primaryKey='bookid';
    protected $fillabe=['authorid','title','ISBN','pub_year','available'];
}

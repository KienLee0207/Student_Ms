<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\book;

class bookController extends Controller
{public function book(){
    $books = book::orderBy("bookid","asc")->paginate(10);

    return view("book", compact("books"));
}
}
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
    <div class="container">
      
            <h2>Quản lý Sách</h2>
            <p>Trường Đại Học FPT</p>            
            <table class="table table-hover">
                <thead>
                    <th>Book Id</th>
                    <th>Author Id</th>
                    <th>Title</th>
                    <th>ISBN</th>
                    <th>Pub year</th>
                    <th>Available</th>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($book->bookid); ?></td>
                           
                            <td><?php echo e($book->authorid); ?></td>
                            <td><?php echo e($book->title); ?></td>
                            <td><?php echo e($book->ISBN); ?></td>
                            <td><?php echo e($book->pub_year); ?></td>
                            <td><?php echo e($book->available); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo $books->links(); ?>

              
            </table>
       
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\practical\resources\views/book.blade.php ENDPATH**/ ?>